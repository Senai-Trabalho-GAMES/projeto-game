import pygame


pygame.init()

largura, altura = 800, 600
tela = pygame.display.set_mode((largura, altura))
pygame.display.set_caption("Viusal")


#BCG atual
RealAtualBG=0


# Coordenadas e tamanho do retângulo
x, y = 40, 390
largura_retangulo, altura_retangulo =720, 170
# Cor do retângulo (no formato RGB)
branco = (255, 255, 255)
cinza = (50, 50, 50)
preto = (0, 0, 0)


under="data/under.ttf"
dark="data/Trajan Regular.ttf"


fonte=pygame.font.Font(dark,19)
texto=f"Teste"
lista=[]
bcg=["sprite/a.png","sprite/b.png"]
cortexto=(255, 255, 255)
textSurface=fonte.render(texto,True,cortexto)
textRect=textSurface.get_rect()


indice_dialogo_atual = 0  # Inicialize com 0 para começar a partir da primeira linha
linhas_por_clique = 4  # Número de linhas a serem exibidas a cada clique


def processarTxt():
    arquivo = "data/dialog.txt"
    with open(arquivo, 'r',encoding='utf-8') as arquivo:
        for linha in arquivo:
            lista.append(linha.strip())


def mostrarBCG(atual):
    background = pygame.image.load(bcg[atual])
    background = pygame.transform.scale(background, (largura, altura))


    tela.blit(background, (0, 0))


def mostrarText():
    global x_texto, yAtual, texto_exibido, indice_dialogo_atual, linhas_por_clique, RealAtualBG
    
    yAtual = y + 15
    atual = RealAtualBG
    mostrarBCG(atual)
    
    for i in range(indice_dialogo_atual, indice_dialogo_atual + linhas_por_clique):
        if i == 6:
            atual = 1
            mostrarBCG(atual)
        
        pygame.draw.rect(tela, cinza, (x - 7, y - 7, largura_retangulo + 14, altura_retangulo + 14), 2)
        pygame.draw.rect(tela, preto, (x, y, largura_retangulo, altura_retangulo))

        if i < len(lista):
            texto_completo = lista[i]
            texto_exibido = ""
        
            for char in texto_completo:
                texto_exibido += char
                textSurface = fonte.render(texto_exibido, True, cortexto)
                textbox_surface = pygame.Surface((largura_retangulo - 75, altura_retangulo - 130))
                textbox_surface.fill(preto)
                textbox_surface.blit(textSurface, (0, 0))
                tela.blit(textbox_surface, (x_texto, yAtual))
                textRect.center = (x + largura_retangulo // 2, y + altura_retangulo // 2)
                pygame.display.update()
                pygame.time.delay(20)  # Atraso entre a exibição de cada caractere

            yAtual += 35
        else:
            pass  # O que vai acontecer depois do diálogo

        

            











mostrarBCG(RealAtualBG)
processarTxt()
x_texto = 65
y_texto = y + (altura_retangulo - textSurface.get_height()) // 2


executando=True
while executando:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            executando = False
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mostrarText()
            indice_dialogo_atual += linhas_por_clique
            pass
    pygame.display.flip()






pygame.quit()
