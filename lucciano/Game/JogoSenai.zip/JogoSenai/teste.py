import pygame


pygame.init()

largura, altura = 1366, 720
tela = pygame.display.set_mode((largura, altura))
pygame.display.set_caption("Viusal")


#BCG atual
RealAtualBG=0


# Coordenadas e tamanho do retângulo
x, y = 250, 455
largura_retangulo, altura_retangulo =890, 240
transparencia=155
# Cor do retângulo (no formato RGB)
branco = (255, 255, 255)
cinza = (50, 50, 50)
preto = (0, 0, 0)


under="data/under.ttf"
dark="data/OptimusPrincepsSemiBold.ttf"
alter="data/Aver.ttf"
alterItalia="data/Aver Italic.ttf"


fonte=pygame.font.Font(alter,22)
fonteName=pygame.font.Font(alterItalia,18)
lista=[]
opcoes_dialogo=[]
nomes=[]
bcg=[]
Hscores=[]
cortexto=(255, 255, 255)


indice_dialogo_atual = 0  # Inicialize com 0 para começar a partir da primeira linha
linhas_por_clique = 4  # Número de linhas a serem exibidas a cada clique
exibicao_lenta=False
pausa=False
consequencias=False
clock = pygame.time.Clock()


def processarTxt():
    arquivo = "data/dialog.txt"
    with open(arquivo, 'r',encoding='utf-8') as arquivo:
        for linha in arquivo:
            lista.append(linha.strip())

    arquivo = "data/choices.txt"
    with open(arquivo, 'r',encoding='utf-8') as arquivo:
        for linha in arquivo:
            opcoes_dialogo.append(linha.strip())

    arquivo = "data/names.txt"
    with open(arquivo, 'r',encoding='utf-8') as arquivo:
        for linha in arquivo:
            nomes.append(linha.strip())

    arquivo = "data/bcg.txt"
    with open(arquivo, 'r',encoding='utf-8') as arquivo:
        for linha in arquivo:
            bcg.append(linha.strip())


def mostrarBCG(atual):
    background = pygame.image.load(bcg[atual])
    background = pygame.transform.scale(background, (largura, altura))


    tela.blit(background, (0, 0))

def mostrarCHAR():
    character = pygame.image.load('sprite/vaporeon.png')
    character = pygame.transform.scale(character, (450, 300))
    char_x = 22 
    char_y = 150

    tela.blit(character, (char_x,char_y))



def mostrarName(aliado):
    if aliado<=-1:
        mostrarBCG(0)# Faz o nome sumir
        pass
    else:
        nome = nomes[aliado]
        NameSurface = fonteName.render(nome, True, cortexto)
        NameRect = NameSurface.get_rect()

        name_x = x + 105  
        name_y = y - 48
        NameRect.center = (name_x, name_y)  # Posição da superfície do nome
        
        pygame.draw.rect(tela, cinza, (x - 5, y - 80, largura_retangulo // 4 + 10, altura_retangulo // 4 + 10), 2)
        pygame.draw.rect(tela, preto, (x, y - 76, largura_retangulo // 4, altura_retangulo // 4))
        
        tela.blit(NameSurface, NameRect)

def mostrarSkip(skip):
    skip0 = "Texto Rápido  ON"
    skip1 = "Texto Rápido  OFF"
    
    if skip == 0:
        transparencia = 100  
    elif skip == 1:
        transparencia = 255
    if exibicao_lenta:
        SkipSurface = fonteName.render(skip1, True, (70,70,70))
    else:
        SkipSurface = fonteName.render(skip0, True, cortexto)
    
    NameRect = SkipSurface.get_rect()

    name_x = 10 
    name_y = 15
    NameRect.center = (name_x+90, name_y+15)  # Alterado de .center para .topleft

    skipbox = pygame.Surface((largura_retangulo // 4 +10, altura_retangulo // 4+10), pygame.SRCALPHA)
    skipbox2 = pygame.Surface((largura_retangulo // 4 , altura_retangulo // 4 ), pygame.SRCALPHA)

    pygame.draw.rect(skipbox, cinza, (0, 0, largura_retangulo // 4 + 10, altura_retangulo // 4 + 10), 2)
    pygame.draw.rect(skipbox2, preto, (0, 0, largura_retangulo // 4, altura_retangulo // 4))

    skipbox.set_alpha(transparencia)
    skipbox2.set_alpha(transparencia)

    tela.blit(skipbox, (5, 5))
    tela.blit(skipbox2, (10, 10))
    tela.blit(SkipSurface, NameRect.topleft)  # Blita o texto na tela na posição especificada

def mostrarChoices(a, b):
    global linhas_por_clique, choice

    tamanho_fonte = 32
    fonte = pygame.font.Font(None, tamanho_fonte)
    executando1 = True
    choice=0
    while executando1:
        # Desenhe a caixa de diálogo
        pygame.draw.rect(tela, preto, (250, 580, 890, 100))  # Interior da caixa
        # Renderize o texto das opções com tamanho variável
        opcao1_superficie = fonte.render(a, True, branco)
        opcao1_rect = opcao1_superficie.get_rect(topleft=(300, 600))
        if opcao1_rect.collidepoint(pygame.mouse.get_pos()):
            tamanho_fonte_aumentado = tamanho_fonte + 5
            fonte = pygame.font.Font(None, tamanho_fonte_aumentado)
        else:
            fonte = pygame.font.Font(None, tamanho_fonte)
        tela.blit(fonte.render(a, True, branco), opcao1_rect)

        opcao2_superficie = fonte.render(b, True, branco)
        opcao2_rect = opcao2_superficie.get_rect(topleft=(300, 650))
        if opcao2_rect.collidepoint(pygame.mouse.get_pos()):
            tamanho_fonte_aumentado = tamanho_fonte + 5
            fonte = pygame.font.Font(None, tamanho_fonte_aumentado)
        else:
            fonte = pygame.font.Font(None, tamanho_fonte)
        tela.blit(fonte.render(b, True, branco), opcao2_rect)

        pygame.display.update()

        for evento in pygame.event.get():
            if evento.type == pygame.MOUSEBUTTONDOWN:
                if evento.button == 1:  # Botão esquerdo do mouse
                    # Verifica se o clique foi em uma das opções
                    if opcao1_rect.collidepoint(evento.pos):
                        choice = 1
                        return choice
                    elif opcao2_rect.collidepoint(evento.pos):
                        choice = 2
                        return choice
                    else:
                        pass
                    if choice==0:
                        pass
                    else:
                        executando1 = False  # Saia do loop após o clique
                    pygame.display.update()
        pygame.display.flip()
        
    

def mostrarConse():
    global choice, consequencias, indice,indice_final
    if choice == 1:
        indice,indice_final = 0,12
    elif choice == 2:
        indice,indice_final = 13,23
    else:
        pass

    consequencias=True


def Pontuação():
    arquivo = "data/Hscores.txt"
    with open(arquivo, 'r',encoding='utf-8') as arquivo:
        for linha in arquivo:
            Hscores.append(linha.strip())



def mostrarText():
    global x_texto, yAtual, texto_exibido, indice_dialogo_atual, linhas_por_clique, RealAtualBG,consequencias,exibicao_lenta,pausa,indice,indice_final
    
    yAtual = y + 15
    atual = RealAtualBG
    
    

    pygame.draw.rect(tela, cinza, (x - 7, y - 7, largura_retangulo + 14, altura_retangulo + 14), 2)
    pygame.draw.rect(tela, preto, (x, y, largura_retangulo, altura_retangulo))
    mostrarName(0)

    textbox_surface = pygame.Surface((largura_retangulo - 75, altura_retangulo - 130))
    textbox_surface.fill(preto)

    if exibicao_lenta: 
        delay=20
    else:
        delay=2
        
    skipb=True
    
    for i in range(indice_dialogo_atual, indice_dialogo_atual + linhas_por_clique):
            if 4 <= i <= 7 and consequencias==False:
                if atual != 1:
                    atual = 1
                    mostrarBCG(atual)
                    mostrarCHAR()
                    mostrarName(1)
                    
                    pygame.draw.rect(tela, cinza, (x - 7, y - 7, largura_retangulo + 14, altura_retangulo + 14), 2)
                    pygame.draw.rect(tela, preto, (x, y, largura_retangulo, altura_retangulo))
            elif 8 <= i <= 11 and consequencias==False:
                if atual != 2:
                    atual = 2
                    mostrarBCG(atual)
                    mostrarName(-2)

                    pygame.draw.rect(tela, cinza, (x - 7, y - 7, largura_retangulo + 14, altura_retangulo + 14), 2)
                    pygame.draw.rect(tela, preto, (x, y, largura_retangulo, altura_retangulo))
            elif i==19:
                a = "Plants Vs Zombies 1"
                b = "Dark Souls no Minecraft"
                escolha = mostrarChoices(a, b)
                print(escolha)
                mostrarConse()
                # break
            if skipb:
                mostrarSkip(0)
                skipb=False
            if i < len(lista):
                if consequencias:
                    texto_completo = opcoes_dialogo[indice]
                    indice+=1
                    if indice>=indice_final:
                        indice_dialogo_atual=20
                        consequencias=False

                else:
                    texto_completo = lista[i]
                texto_exibido = ""
            
                for char in texto_completo:
                    texto_exibido += char
                    textSurface = fonte.render(texto_exibido, True, cortexto)
                    textbox_surface.fill(preto)
                    textbox_surface.blit(textSurface, (0, 0))
                    tela.blit(textbox_surface, (x_texto, yAtual))
                    pygame.display.update()
                    pygame.time.delay(delay)  # Atraso entre a exibição de cada caractere

                yAtual += 35
            else:
                Pontuação()
                pass  # O que vai acontecer depois do diálogo
        
    mostrarSkip(1)
    

            



processarTxt()
mostrarBCG(RealAtualBG)
x_texto = 275


executando=True
executando = True
while executando:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            executando = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                exibicao_lenta = not exibicao_lenta
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if pausa:
                pass
            else:
                mostrarText()
                indice_dialogo_atual += linhas_por_clique

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
