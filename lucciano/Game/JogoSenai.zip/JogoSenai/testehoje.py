import pygame
import sys

# Inicialização do Pygame
pygame.init()

# Configurações iniciais
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Sistema de Pontuação")

# Carregar música de fundo
pygame.mixer.music.load("sounds/GameOverYEAH.mp3")
pygame.mixer.music.play(-1)  # Repetir indefinidamente

# Função para carregar as pontuações do arquivo de texto
def carregar_pontuacoes():
    try:
        with open("pontuacoes.txt", "r") as file:
            pontuacoes = [line.strip().split(",") for line in file]
            return sorted(pontuacoes, key=lambda x: int(x[1]), reverse=True)
    except FileNotFoundError:
        return []

# Função para salvar as pontuações no arquivo de texto
def salvar_pontuacoes(pontuacoes):
    with open("pontuacoes.txt", "w") as file:
        for nome, moralidade in pontuacoes:
            file.write(f"{nome},{moralidade}\n")

# Carregar as pontuações existentes
pontuacoes = carregar_pontuacoes()

# Loop principal do jogo
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Exibir as 10 principais pontuações
    screen.fill((255, 255, 255))  # Fundo branco
    font = pygame.font.Font(None, 36)
    text_y = 50
    for i, (nome, moralidade) in enumerate(pontuacoes[:10]):
        text_surface = font.render(f"{i + 1}. {nome}: {moralidade}", True, (0, 0, 0))
        screen.blit(text_surface, (screen_width // 2 - 100, text_y))
        text_y += 40

    # Pedir ao usuário para inserir seu nome (limite de 5 caracteres)
    input_box = pygame.Rect(screen_width // 2 - 100, 200, 200, 32)
    font = pygame.font.Font(None, 32)
    color_inactive = pygame.Color('lightskyblue3')
    color_active = pygame.Color('dodgerblue2')
    color = color_inactive
    nome = ""
    active = False

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if input_box.collidepoint(event.pos):
                    active = not active
                else:
                    active = False
                color = color_active if active else color_inactive
            if event.type == pygame.KEYDOWN:
                if active:
                    if event.key == pygame.K_RETURN:
                        # Calcular a moralidade do usuário (implemente sua própria lógica)
                        # moralidade = calcular_moralidade()
                        
                        # Adicionar o novo usuário às pontuações, se for digno
                        if moralidade > 0:
                            pontuacoes.append((nome, moralidade))
                            pontuacoes = sorted(pontuacoes, key=lambda x: int(x[1]), reverse=True)[:10]
                            salvar_pontuacoes(pontuacoes)
                        
                        nome = ""
                    elif event.key == pygame.K_BACKSPACE:
                        nome = nome[:-1]
                    else:
                        if len(nome) < 5:
                            nome += event.unicode

        screen.fill((255, 255, 255))  # Fundo branco
        txt_surface = font.render(nome, True, color)
        width = max(200, txt_surface.get_width() + 10)
        input_box.w = width
        screen.blit(txt_surface, (input_box.x + 5, input_box.y + 5))
        pygame.draw.rect(screen, color, input_box, 2)
        pygame.display.flip()

# Encerrar o Pygame
pygame.quit()
