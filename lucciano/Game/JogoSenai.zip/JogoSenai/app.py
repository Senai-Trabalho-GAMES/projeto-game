'''
    Projeto por:
    LALESCA NASCIMENTO RODRIGUES, LUCIANO GOMES DE FARIA, PEDRO NOGUEIRA STEPHAN, RAQUEL VITÓRIA MARCELINO OLIVEIRA

    Vídeo de exibição:
    https://youtu.be/cK9tfNTVIa8
'''
import pygame, json, time

pygame.init() # Inicia o jogo através do Pygame


largura, altura = 1366, 720                       # Variáveis de dimensão da tela
tela = pygame.display.set_mode((largura, altura)) # Define variável "tela" como tela principal
icon = pygame.image.load('sprite/icon.png')
pygame.display.set_icon(icon)
pygame.display.set_caption("Dark Sale")           # Nome que aparece na toolbar da janela


RealAtualBG=0 # BCG atual
items=0       # Score exibido no final ao lado do nome dos jogadores

# Coordenadas e tamanho do retângulo
x, y = 250, 455
largura_retangulo, altura_retangulo = 890, 240

# Variável da transparência do retângulo que indica se a exibição rápida está ativada ou não
transparencia=20

# Cores utilizadas no código para pintar retângulos e textos
branco = (255, 255, 255)
cinza = (50, 50, 50)
preto = (0, 0, 0)
gameover = (202,37,13)

# Fontes utilizadas nos textos do jogo
alter="data/Aver.ttf"
alterItalia="data/Aver Italic.ttf"
score="data/Normandy.otf"
fonte=pygame.font.Font(alter,22)
fonteName=pygame.font.Font(alterItalia,18)
fonteScore=pygame.font.Font(score,33)

# Sons utilizados no jogo
gameEnd= pygame.mixer.Sound('sounds/GameOverYEAH.mp3')
somMenu= pygame.mixer.Sound('sounds/SomEstridentee.mp3')
theme= pygame.mixer.Sound('sounds/Music.mp3')


# Listas utilizadas no jogo, para melhor leitura de arquivos

dialog=[]         # Contém o arquivo 'dialog.txt' processado - texto principal.
opcoes_dialogo=[] # Contém o arquivo 'choices.txt' processado - consequências das escolhas do jogador.
nomes=[]          # Contém o arquivo 'names.txt' processado - nome dos personagens que aparecem na história e que possuem falas.
bcg=[]            # Contém o arquivo 'bcg.txt' processado - o caminho das imagens usadas no jogo, para melhor chamada.
Hscores=[]        # Contém o arquivo 'hscores.json' processado - a pontuação dos jogadores e seus nomes.


indice_dialogo_atual = 0    # Indice de onde o texto se encontra, começa no 0.
linhas_por_clique = 4       # Adiciona 4 ao indice_dialogo_atual, exibindo 4 novas linhas por clique.
exibicao_lenta=True         # Variável que controla a velocidade de diálogo, começa lenta.
fim=False                   # Variável que checa se o jogo acabou.
consequencias=False         # Variável que checa se uma consequência está atualmente acontecendo, para evitar conflitos entre arquivos.
clock = pygame.time.Clock() # Define o relógio que conta frame por frame


def processarTxt(): # Processa os arquivos e os convertem em listas, para serem exibidos no jogo.
    arquivo = "data/dialog.txt"
    with open(arquivo, 'r',encoding='utf-8') as arquivo:
        for linha in arquivo:
            dialog.append(linha.strip())

    arquivo = "data/choices.txt"
    with open(arquivo, 'r',encoding='utf-8') as arquivo:
        for linha in arquivo:
            opcoes_dialogo.append(linha.strip())

    arquivo = "data/names.txt"
    with open(arquivo, 'r',encoding='utf-8') as arquivo:
        for linha in arquivo:
            nomes.append(linha.strip())

    arquivo = "data/bcg.txt"
    with open(arquivo, 'r',encoding='utf-8') as arquivo:
        for linha in arquivo:
            bcg.append(linha.strip())

def mostrarBCG(atual): # Exibe o Background, baseado no índice da lista.
    background = pygame.image.load(bcg[atual])
    background = pygame.transform.scale(background, (largura, altura))


    tela.blit(background, (0, 0))

def mostrarName(aliado): # Exibe o retângulo que contém os nomes dos personagens, e o nome dos personagens
    nome = nomes[aliado]
    NameSurface = fonteName.render(nome, True, branco)
    NameRect = NameSurface.get_rect()

    name_x = x + 105  
    name_y = y - 48
    NameRect.center = (name_x, name_y)  # Posição da superfície do nome
        
    pygame.draw.rect(tela, cinza, (x - 5, y - 80, largura_retangulo // 4 + 10, altura_retangulo // 4 + 10), 2)
    pygame.draw.rect(tela, preto, (x, y - 76, largura_retangulo // 4, altura_retangulo // 4))
        
    tela.blit(NameSurface, NameRect)

def mostrarSkip(skip): # Desenha o retângulo que contém o status da velocidade do texto.
    skip0 = "Texto Rápido  ON"
    skip1 = "Texto Rápido  OFF"
    
    if skip == 0:
        transparencia = 20
    elif skip == 1:
        transparencia = 255
    if exibicao_lenta:
        SkipSurface = fonteName.render(skip1, True, (70,70,70))
    else:
        SkipSurface = fonteName.render(skip0, True, branco)
    
    NameRect = SkipSurface.get_rect()

    name_x = 10 
    name_y = 15
    NameRect.center = (name_x+90, name_y+15)  

    skipbox = pygame.Surface((largura_retangulo // 4 +10, altura_retangulo // 4+10), pygame.SRCALPHA)
    skipbox2 = pygame.Surface((largura_retangulo // 4 , altura_retangulo // 4 ), pygame.SRCALPHA)

    pygame.draw.rect(skipbox, cinza, (0, 0, largura_retangulo // 4 + 10, altura_retangulo // 4 + 10), 2)
    pygame.draw.rect(skipbox2, preto, (0, 0, largura_retangulo // 4, altura_retangulo // 4))

    skipbox.set_alpha(transparencia)
    skipbox2.set_alpha(transparencia)

    tela.blit(skipbox, (5, 5))
    tela.blit(skipbox2, (10, 10))
    tela.blit(SkipSurface, NameRect.topleft) 

def mostrarChoices(a, b): # Exibe duas escolhas para o jogador: 'a' e 'b'
    global linhas_por_clique, choice

    tamanho_fonte = 22
    fonte = pygame.font.Font(alterItalia, tamanho_fonte)
    executando1 = True
    choice=0
    while executando1:
        pygame.draw.rect(tela, preto, (250, 580, 890, 100))
        opcao1_superficie = fonte.render(a, True, branco)
        opcao1_rect = opcao1_superficie.get_rect(topleft=(300, 600))
        if opcao1_rect.collidepoint(pygame.mouse.get_pos()):
            tamanho_fonte_aumentado = tamanho_fonte + 5
            fonte = pygame.font.Font(alterItalia, tamanho_fonte_aumentado)
        else:
            fonte = pygame.font.Font(alterItalia, tamanho_fonte)
        tela.blit(fonte.render(a, True, branco), opcao1_rect)

        opcao2_superficie = fonte.render(b, True, branco)
        opcao2_rect = opcao2_superficie.get_rect(topleft=(300, 650))
        if opcao2_rect.collidepoint(pygame.mouse.get_pos()):
            tamanho_fonte_aumentado = tamanho_fonte + 5
            fonte = pygame.font.Font(alterItalia, tamanho_fonte_aumentado)
        else:
            fonte = pygame.font.Font(alterItalia, tamanho_fonte)
        tela.blit(fonte.render(b, True, branco), opcao2_rect)

        pygame.display.update() # Atualiza certos aspectos da tela

        for evento in pygame.event.get():
            if evento.type == pygame.MOUSEBUTTONDOWN:
                if evento.button == 1: 
                    # Verifica se o clique foi em uma das opções, e informa ao sistema qual foi escolhida.
                    if opcao1_rect.collidepoint(evento.pos):
                        choice = 1
                        return choice
                    elif opcao2_rect.collidepoint(evento.pos):
                        choice = 2
                        return choice
                    else: # Caso clique na tela, nada acontece
                        pass
                    if choice==0:
                        pass
                    else:
                        executando1 = False  
                    pygame.display.update()
        pygame.display.flip()
        
def mostrarConse(Ac,AcEnd,Bc,BcEnd): # Exibe as consequências das suas escolhas.
    global choice, consequencias, indice,indice_final
    if choice == 1:
        indice,indice_final = Ac,AcEnd # 'Ac' indica o indice do começo do texto da consequência, 'AcEnd' indica o fim.
    elif choice == 2:
        indice,indice_final = Bc,BcEnd # Idem.
    else:
        pass

    consequencias=True # Informa o programa que uma consequência está acontecendo.

def Pontuação(): # Exibe o nome do jogador e sua pontuação.
    rX=342+85
    rY=90
    
    gameEnd.play()

    name="Você" # Devido à limitações, você é 'Você' na tela de pontuação.

    player={'nome':name,'pts':items} # Aqui, as informações do jogador são armazenadas em um dicionário, que é então armazenado em 'player'.
   
    with open('data/hscores.json', 'r') as arquivo: # 'hscores.json' é armazenado na lista 'Hscores'
        Hscores = json.load(arquivo)
    
    Hscores.append(player) # 'player' é armazenado em 'Hscores'

    Hscores = sorted(Hscores, key=lambda x: x['pts'], reverse=True) # 'Hscores' é organizada em ordem decrescente baseada nas pontuações dos jogadores

    with open('data/hscores.json', 'w') as arquivo: # 'Hscores' é então armazenado em 'hscores.json', para gravar as pontuações de cada gameplay
        json.dump(Hscores, arquivo)

    # A tela de GameOver é iniciada
    imagemGameOver = pygame.image.load('sprite/GAMEOVERYEAH.png')
    imagemGameFundoOver = pygame.image.load('sprite/GAMEOVERYEAH (2).png')
    tela.blit(imagemGameFundoOver, (0,0))
    tela.blit(imagemGameOver, (rX, rY-200))
    rY+=13

    for score in Hscores: # E finalmente 'Hscores' é exibido na tela de GameOver
        name=score["nome"]
        pts=score["pts"]
        otherPlayers=f"{name}                      {pts}"
        texto_renderizado = fonteScore.render(otherPlayers, True, gameover)

        retangulo = pygame.Rect(rX, rY, 500, 60)
        
        texto_retangulo = texto_renderizado.get_rect()
        texto_retangulo.center = retangulo.center

        pygame.draw.rect(tela, branco, retangulo)  # Desenhe o retângulo na tela
        tela.blit(texto_renderizado, texto_retangulo.topleft)

        rY+=55
        pygame.display.update() # As informações na tela são atualizadas
        pygame.time.delay(300)  # Com um intervalo de 300 frames entre cada score

    pygame.time.delay(5000) # O jogo espera 5 segundos depois da exibição dos pontos e então fecha.


def mostrarText(): # Esta função é em essência, o jogo.
    global atual,items, escolha1, escolha2, escolha3, escolha4, escolha5, x_texto, yAtual, texto_exibido, indice_dialogo_atual, linhas_por_clique, RealAtualBG,consequencias,exibicao_lenta,fim,indice,indice_final,executando

    yAtual = y + 15
    atual = RealAtualBG
    
    # Desenha os retângulos que formar a caixa de texto
    pygame.draw.rect(tela, cinza, (x - 7, y - 7, largura_retangulo + 14, altura_retangulo + 14), 2)
    pygame.draw.rect(tela, preto, (x, y, largura_retangulo, altura_retangulo))

    textbox_surface = pygame.Surface((largura_retangulo - 75, altura_retangulo - 130))
    textbox_surface.fill(preto)

    # 'delay' é a velocidade do texto exibido.
    if exibicao_lenta: 
        delay=15
    else:
        delay=2
        
    skipb=True # Controla a exibição da SkipBox
    
    # Loop que exibe 4 linhas na tela. Começa no indice_dialogo_atual, e acaba depois de 4 iterações.
    # Cada 'i' é uma linha, e eventos são controlados a partir do indice da linha.
    for i in range(indice_dialogo_atual, indice_dialogo_atual + linhas_por_clique):
            # Controla os backgrounds exibidos.
            if i>=0 and i< 1 and consequencias==False:
                if atual != 1:
                    atual = 1
                    mostrarBCG(atual)
                    pygame.display.update()
                pygame.time.delay(4000)
                pygame.draw.rect(tela, cinza, (x - 7, y - 7, largura_retangulo + 14, altura_retangulo + 14), 2)
                pygame.draw.rect(tela, preto, (x, y, largura_retangulo, altura_retangulo))
                pygame.display.update()
            elif i>=28 and i< 29 and consequencias==False:
                if atual != 2:
                    atual = 2
                    mostrarBCG(atual)
                    pygame.display.update()
                pygame.time.delay(4000)
                pygame.draw.rect(tela, cinza, (x - 7, y - 7, largura_retangulo + 14, altura_retangulo + 14), 2)
                pygame.draw.rect(tela, preto, (x, y, largura_retangulo, altura_retangulo))
                pygame.display.update()
            elif i>=72 and i< 73 and consequencias==False:
                if atual != 2:
                    atual = 2
                    mostrarBCG(atual)
                    pygame.display.update()
                pygame.time.delay(4000)
                pygame.draw.rect(tela, cinza, (x - 7, y - 7, largura_retangulo + 14, altura_retangulo + 14), 2)
                pygame.draw.rect(tela, preto, (x, y, largura_retangulo, altura_retangulo))
                pygame.display.update()
            elif i>=120 and i< 121 and consequencias==False:
                if atual != 2:
                    atual = 2
                    mostrarBCG(atual)
                    pygame.display.update()
                pygame.time.delay(4000)
                pygame.draw.rect(tela, cinza, (x - 7, y - 7, largura_retangulo + 14, altura_retangulo + 14), 2)
                pygame.draw.rect(tela, preto, (x, y, largura_retangulo, altura_retangulo))
                pygame.display.update()
            elif i>=177 and i< 178 and consequencias==False:
                if atual != 2:
                    atual = 2
                    mostrarBCG(atual)
                    pygame.display.update()
                pygame.time.delay(4000)
                pygame.draw.rect(tela, cinza, (x - 7, y - 7, largura_retangulo + 14, altura_retangulo + 14), 2)
                pygame.draw.rect(tela, preto, (x, y, largura_retangulo, altura_retangulo))
                pygame.display.update()
            elif i>=52 and i< 53 and consequencias==False:
                if atual != 3:
                    atual = 3
                    mostrarBCG(atual)
                    pygame.display.update()
                pygame.time.delay(4000)
                pygame.draw.rect(tela, cinza, (x - 7, y - 7, largura_retangulo + 14, altura_retangulo + 14), 2)
                pygame.draw.rect(tela, preto, (x, y, largura_retangulo, altura_retangulo))
                pygame.display.update()
            elif i>=92 and i< 93 and consequencias==False:
                if atual != 4:
                    atual = 4
                    mostrarBCG(atual)
                    pygame.display.update()
                pygame.time.delay(4000)
                pygame.draw.rect(tela, cinza, (x - 7, y - 7, largura_retangulo + 14, altura_retangulo + 14), 2)
                pygame.draw.rect(tela, preto, (x, y, largura_retangulo, altura_retangulo))
                pygame.display.update()
            elif i>=152 and i< 153 and consequencias==False:
                if atual != 5:
                    atual = 5
                    mostrarBCG(atual)
                    pygame.display.update()
                pygame.time.delay(4000)
                pygame.draw.rect(tela, cinza, (x - 7, y - 7, largura_retangulo + 14, altura_retangulo + 14), 2)
                pygame.draw.rect(tela, preto, (x, y, largura_retangulo, altura_retangulo))
                pygame.display.update()
            elif i>=193 and i< 194 and consequencias==False:
                if atual != 6:
                    atual = 6
                    mostrarBCG(atual)
                    pygame.display.update()
                pygame.time.delay(4000)
                pygame.draw.rect(tela, cinza, (x - 7, y - 7, largura_retangulo + 14, altura_retangulo + 14), 2)
                pygame.draw.rect(tela, preto, (x, y, largura_retangulo, altura_retangulo))
                pygame.display.update()
            # Controla as caixas que exibem os nomes.
            if i>=32 and i< 33 and consequencias==False:
                mostrarName(0)
                pygame.display.update()
            elif i>=36 and i< 37 and consequencias==False:
                mostrarBCG(2)
                pygame.draw.rect(tela, cinza, (x - 7, y - 7, largura_retangulo + 14, altura_retangulo + 14), 2)
                pygame.draw.rect(tela, preto, (x, y, largura_retangulo, altura_retangulo))
                pygame.display.update()
            elif i>=44 and i< 45 and consequencias==False:
                mostrarName(1)
                pygame.display.update()
            elif i>=48 and i< 49 and consequencias==False:
                mostrarBCG(2)
                pygame.draw.rect(tela, cinza, (x - 7, y - 7, largura_retangulo + 14, altura_retangulo + 14), 2)
                pygame.draw.rect(tela, preto, (x, y, largura_retangulo, altura_retangulo))
                pygame.display.update()
            elif i>=76 and i< 77 and consequencias==False:
                mostrarName(2)
                pygame.display.update()
            elif i>=88 and i< 89 and consequencias==False:
                mostrarBCG(2)
                pygame.draw.rect(tela, cinza, (x - 7, y - 7, largura_retangulo + 14, altura_retangulo + 14), 2)
                pygame.draw.rect(tela, preto, (x, y, largura_retangulo, altura_retangulo))
                pygame.display.update()

            elif i>=132 and i< 133 and consequencias==False:
                mostrarName(1)
                pygame.display.update()
            elif i>=140 and i< 141 and consequencias==False:
                mostrarBCG(2)
                pygame.draw.rect(tela, cinza, (x - 7, y - 7, largura_retangulo + 14, altura_retangulo + 14), 2)
                pygame.draw.rect(tela, preto, (x, y, largura_retangulo, altura_retangulo))
                pygame.display.update()
            # Controla as escolhas exibidas no jogo.
            if i>=24 and i< 25 and consequencias==False:
                escolha1=True
                a='[*Seguir o mapa]'
                b='[*Ir embora]'
                Ac,AcEnd = 14,18
                Bc,BcEnd = 0,12
                mostrarChoices(a,b)
                mostrarConse(Ac,AcEnd,Bc,BcEnd)
                pygame.draw.rect(tela, cinza, (x - 7, y - 7, largura_retangulo + 14, altura_retangulo + 14), 2)
                pygame.draw.rect(tela, preto, (x, y, largura_retangulo, altura_retangulo))
            if i>=64 and i< 65 and consequencias==False:
                escolha2=True
                a='[*Tentar a sorte, pegar o item]'
                b='[*Não vale a pena]'
                Ac,AcEnd = 20,24
                Bc,BcEnd = 25,33
                mostrarChoices(a,b)
                mostrarConse(Ac,AcEnd,Bc,BcEnd)
                pygame.draw.rect(tela, cinza, (x - 7, y - 7, largura_retangulo + 14, altura_retangulo + 14), 2)
                pygame.draw.rect(tela, preto, (x, y, largura_retangulo, altura_retangulo))
            if i>=112 and i< 113 and consequencias==False:
                escolha3=True
                a='[*Abrir o baú]'
                b='[*Pensando bem...]'
                Ac,AcEnd = 35,43
                Bc,BcEnd = 44,56
                mostrarChoices(a,b)
                mostrarConse(Ac,AcEnd,Bc,BcEnd)   
                pygame.draw.rect(tela, cinza, (x - 7, y - 7, largura_retangulo + 14, altura_retangulo + 14), 2)
                pygame.draw.rect(tela, preto, (x, y, largura_retangulo, altura_retangulo))
            if i>=172 and i< 173 and consequencias==False:
                escolha4=True
                a='[*...Corre]!'
                b='[*Pensar com calma]'
                Ac,AcEnd = 58,70
                Bc,BcEnd = 71,83
                mostrarChoices(a,b)
                mostrarConse(Ac,AcEnd,Bc,BcEnd)
                pygame.draw.rect(tela, cinza, (x - 7, y - 7, largura_retangulo + 14, altura_retangulo + 14), 2)
                pygame.draw.rect(tela, preto, (x, y, largura_retangulo, altura_retangulo))
            if i>=197 and i< 198 and consequencias==False:
                escolha5=True
                a='[*Ajudar a chama]'
                b='[*Partir de Firelink Shrine]'
                Ac,AcEnd = 85,92
                Bc,BcEnd = 94,102
                mostrarChoices(a,b)
                mostrarConse(Ac,AcEnd,Bc,BcEnd)
                pygame.draw.rect(tela, cinza, (x - 7, y - 7, largura_retangulo + 14, altura_retangulo + 14), 2)
                pygame.draw.rect(tela, preto, (x, y, largura_retangulo, altura_retangulo))
            if skipb: # Exibe a SkipBox uma vez e então espera o próximo clique.
                mostrarSkip(0)
                skipb=False
            if i < len(dialog):   # Exibe texto se 'i' ainda não tiver alcançado o fim do texto.
                if consequencias: # Se 'consequencias' for verdadeiro, o texto exibido é 'choices.txt'
                    texto_completo = opcoes_dialogo[indice]
                    indice+=1
                    if indice>=indice_final:            # Acontece se a consequência já acabou
                        if escolha1==True:              # Checa em qual escolha estamos e informa ao programa qual linha o texto deve continuar em 'dialog.txt', menos 4, que é adicionado por clique.
                            if choice == 1:             # Caso o jogador escolha a primeira opção: 
                                indice_dialogo_atual=24 # Linha onde o texto pós consequência começará, menos 4, adicionado por clique.
                                items+=1                # Sua pontuação final aumenta
                                consequencias=False     # Finaliza o segmento e retorna ao texto principal.
                            elif choice == 2:           # Caso o jogador escolha a segunda opção:
                                fim=True                # Finaliza o jogo.
                                consequencias=False
                            escolha1=False
                        if escolha2:
                            if choice == 1:
                                items+=1
                                consequencias=False
                            elif choice == 2:
                                consequencias=False
                            indice_dialogo_atual=64 
                            escolha2=False
                        if escolha3:
                            if choice == 1:
                                fim=True 
                                consequencias=False
                            elif choice == 2:
                                indice_dialogo_atual=112
                                items+=1
                                consequencias=False
                            escolha3=False
                        if escolha4:
                            if choice == 1:
                                consequencias=False
                            elif choice == 2:
                                items+=1
                                consequencias=False
                            indice_dialogo_atual=173
                            escolha4=False
                        if escolha5:
                            if choice == 1:
                                consequencias=False
                            elif choice == 2:
                                consequencias=False
                            fim=True 
                            escolha5=False
                else:
                    texto_completo = dialog[i] # Texto que é primáriamente exibido, completo.
                texto_exibido = ""             # Texto exibido, incrementado e imprimido a cada loop para criar a animação presente no texto.
            
                for char in texto_completo:    # Adiciona a linha caractere por caractere, exibe a variável letra por letra, e cria a animação. 
                    texto_exibido += char
                    textSurface = fonte.render(texto_exibido, True, branco)
                    textbox_surface.fill(preto)# Enche a caixa de diálogo com a cor preta, para que os textos não se sobreponham
                    textbox_surface.blit(textSurface, (0, 0))
                    tela.blit(textbox_surface, (x_texto, yAtual)) # Exibe o texto em 'x_texto' e 'yAtual'
                    pygame.display.update()
                    pygame.time.delay(delay)   # Atraso entre a exibição de cada caractere.
                yAtual += 35 # 'y' é a posição da primeira linha, 'yAtual' é a coordenada da próxima linha
            else:   # Quando o texto acabar, isso acontece.
                fim=True
                executando = False
                pass 
        
    mostrarSkip(1) # Mostra a skipBox em 255 de transparencia, indicando que agora é possível mudar a velocidade do texto exibido.


processarTxt()      # Processa o texto, armazenando o nas suas respectivas listas.
tela.fill((0,0,0))  # Enche a tela da cor preta.
x_texto = 275       # Coordenada X do texto, onde ele é exibido na tela.

frase="Clique para continuar..." # Frase que pisca na tela inicial
frase2="..."                     # Reticencias piscantes que indica o fim da impressão da tela
fonteBold = pygame.font.Font('data/Aver Bold.ttf', 24)
fonteBBIG = pygame.font.Font('data/Aver Bold.ttf', 38)

posicao_x = (largura - fonteBold.size(frase)[0]) // 2 # Coordenada X onde a 'frase' é exibida
posicao_y = altura + 20                               # O texto começa abaixo da tela
posicao_x_triang = 1100                               # Idem, info da 'frase2'
posicao_y_triang = 650  


piscando = True # Variável para controlar o tempo de piscagem
gameStart = False # Variável para checar se o jogo começou
escolha1=False # Variáveis que controlam as escolhas feitas
escolha2=False
escolha3=False
escolha4=False
escolha5=False

theme.set_volume(0.5)
theme.play() # Toca o som ambiente do jogo

executando = True
while executando: # Loop principal
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            executando = False # Finaliza o jogo caso aperte o botão X da toolbar da janela
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE: # Se o botão espaço for apertado, exibicao_lenta é ativada ou desativada
                exibicao_lenta = not exibicao_lenta
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1: # Tudo que é controlado pro clique no jogo fica aqui
            if gameStart==False: # Se o jogo não começou ainda, o clique irá tocar um som e uma imagem preta irá se materializar aos poucos.
                gameStart=True   # Informa ao programa que o jogo começou
                somMenu.play()   # Toca o efeito
                transition = pygame.image.load('sprite/black.png').convert_alpha()
                transition = pygame.transform.scale(transition, (largura, altura))
                for alpha in range(0,256): # Lentamente exibe a imagem preta como forma de transição
                    transition.set_alpha(alpha)
                    tela.blit(transition, (0, 0))
                    pygame.display.flip()
                    pygame.time.delay(20)
                time.sleep(2.0) # "Trava" a tela por 2 segundos
            if fim:                     # Se o jogo acabou:
                theme.set_volume(0.0)   # Muta a música do jogo
                for alpha in range(0,256): # Lentamente exibe a imagem preta como forma de transição
                    transition.set_alpha(alpha)
                    tela.blit(transition, (0, 0))
                    pygame.display.flip()
                    pygame.time.delay(20)
                Pontuação()             # Ativa a sequência da pontuação
                executando=False        # Fecha o jogo.
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1: # Se o jogo ainda não acabou:
                mostrarText()                                                # Mostrar o texto, 4 linhas por vez
                indice_dialogo_atual += linhas_por_clique                    # Incrementa o indice_dialogo_atual em 4 a cada clique, até o final do jogo.
    
    if gameStart==False:              # Se o jogo não começou, exibe a tela inicial
        mostrarBCG(RealAtualBG)

    if piscando and gameStart==False: # Se o jogo não começou, pisca o texto na tela
        texto = fonteBold.render(frase, True, branco)
        tela.blit(texto, (posicao_x, posicao_y))

    if gameStart==False:
        pygame.display.update()       # Atualiza a tela

        posicao_y = 600               # Traz o texto de volta à tela

        pygame.time.delay(1000)       # Espera 1000 frames até piscar de novo

        piscando = not piscando       # Inverte o estado de piscagem

    if piscando and gameStart:        # Se o jogo já começou, piscar a reticencias na tela para indicar interação disponível
        texto = fonteBBIG.render(frase2, True, branco)
        tela.blit(texto, (posicao_x_triang, posicao_y_triang))
    elif piscando==False and gameStart:
        pygame.draw.rect(tela, preto, (posicao_x_triang, posicao_y_triang, 35, 35))

    if gameStart:
        pygame.display.update()

        posicao_y = 600  

        pygame.time.delay(500)

        piscando = not piscando  

    pygame.display.flip()   # Atualiza a tela inteira a cada frame
    clock.tick(60)          # Limita os frames por segundo do jogo para 60 frames

pygame.quit()               # Finaliza o jogo