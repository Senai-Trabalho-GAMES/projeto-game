import pygame
import sys

pygame.init()

# Configurações da janela
largura, altura = 800, 600
tela = pygame.display.set_mode((largura, altura))
pygame.display.set_caption("Esfera com Borda")

# Cores
branco = (255, 255, 255)
preto = (0, 0, 0)
vermelho = (255, 0, 0)

# Variáveis de controle
transparencia_borda = 128  # Transparência inicial da borda (0 a 255)
funcao_ativada = False  # Flag para indicar se a função está ativada

# Função para desenhar a esfera
def desenhar_esfera():
    # Círculo interno (esfera)
    pygame.draw.circle(tela, branco, (largura // 2, altura // 2), 100)

    # Borda da esfera
    pygame.draw.circle(tela, vermelho, (largura // 2, altura // 2), 100, 5)

# Loop principal
executando = True
clock = pygame.time.Clock()

while executando:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            executando = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                # Alterna a função ativada/desativada
                funcao_ativada = not funcao_ativada
                if funcao_ativada:
                    transparencia_borda = 255  # Ativar: tornar a borda opaca
                else:
                    transparencia_borda = 128  # Desativar: tornar a borda semi-transparente

    tela.fill(preto)

    # Desenhar a esfera com a borda que muda de transparência
    pygame.Surface.set_alpha(tela, transparencia_borda)  # Define a transparência da tela
    desenhar_esfera()
    pygame.Surface.set_alpha(tela, 255)  # Restaura a transparência da tela para opaco

    pygame.display.flip()
    clock.tick(60)  # Limite de taxa de quadros para 60 FPS

pygame.quit()
sys.exit()
